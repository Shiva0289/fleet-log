
📘 Fleet Log Book App - How to Host Online

STEP 1: Go to https://github.com and create a free account (if you don't have one)

STEP 2: Create a new repository (name it something like 'fleet-log-book')

STEP 3: Upload the 'index.html' file into that repository

STEP 4: Go to "Settings" > "Pages" > Source: select 'main' branch and / (root), then click Save

STEP 5: Your app will be live at: https://yourusername.github.io/fleet-log-book/

Open that link in your phone or browser to use the live version! 🎉

NOTE: Make sure your Google Sheet has the correct headers and is shared with "Anyone with the link can edit"
